<?php

namespace Ocr;

class Ocr
{
    public static function say()
    {
        echo 'hello';
    }
}